%TF.GenerationSoftware,KiCad,Pcbnew,10.99.0-3758-g2f18d95be7*%
%TF.CreationDate,2026-09-13T06:00:11+01:00*%
%TF.ProjectId,kicad_file,6b696361-645f-4666-996c-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.99.0-3758-g2f18d95be7) date 2026-09-13 06:00:11*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMOutline5P*
0 Free polygon, 5 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 5*
0 $1 to $10 corner X, Y*
0 $11 Rotation angle, in degrees counterclockwise*
0 create outline with 5 corners*
4,1,5,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$1,$2,$11*%
%AMOutline6P*
0 Free polygon, 6 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 6*
0 $1 to $12 corner X, Y*
0 $13 Rotation angle, in degrees counterclockwise*
0 create outline with 6 corners*
4,1,6,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$1,$2,$13*%
%AMOutline7P*
0 Free polygon, 7 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 7*
0 $1 to $14 corner X, Y*
0 $15 Rotation angle, in degrees counterclockwise*
0 create outline with 7 corners*
4,1,7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$1,$2,$15*%
%AMOutline8P*
0 Free polygon, 8 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 8*
0 $1 to $16 corner X, Y*
0 $17 Rotation angle, in degrees counterclockwise*
0 create outline with 8 corners*
4,1,8,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$1,$2,$17*%
G04 Aperture macros list end*
%TA.AperFunction,ComponentPad*%
%ADD10C,1.320800*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD11Outline8P,-0.838200X0.347194X-0.347194X0.838200X0.347194X0.838200X0.838200X0.347194X0.838200X-0.347194X0.347194X-0.838200X-0.347194X-0.838200X-0.838200X-0.347194X180.000000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD12Outline8P,-0.838200X0.347194X-0.347194X0.838200X0.347194X0.838200X0.838200X0.347194X0.838200X-0.347194X0.347194X-0.838200X-0.347194X-0.838200X-0.838200X-0.347194X90.000000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD13O,2.641600X1.320800*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD14C,3.175000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD15R,3.962400X3.962400*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD16O,3.048000X1.524000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD17Outline8P,-0.838200X0.347194X-0.347194X0.838200X0.347194X0.838200X0.838200X0.347194X0.838200X-0.347194X0.347194X-0.838200X-0.347194X-0.838200X-0.838200X-0.347194X-90.000000*%
%TD*%
G04 APERTURE END LIST*
D10*
%TO.N,N$15*%
%TO.C,Q1*%
X18415000Y17018000D03*
%TO.N,N$14*%
X18415000Y14478000D03*
%TD*%
D11*
%TO.N,VCC*%
%TO.C,C1*%
X4826000Y8636000D03*
%TO.N,GND*%
X2286000Y8636000D03*
%TD*%
D12*
%TO.N,VCC*%
%TO.C,R2*%
X8382000Y1524000D03*
%TO.N,SCL*%
X8382000Y11684000D03*
%TD*%
D13*
%TO.N,N$14*%
%TO.C,IC3*%
X15621000Y14478000D03*
%TO.N,N$15*%
X15621000Y17018000D03*
%TO.N,N$39*%
X15621000Y19558000D03*
%TO.N,GND*%
X15621000Y22098000D03*
%TO.N,SDA*%
X8001000Y22098000D03*
%TO.N,SCL*%
X8001000Y19558000D03*
%TO.N,SQW*%
X8001000Y17018000D03*
%TO.N,VCC*%
X8001000Y14478000D03*
%TD*%
D14*
%TO.N,N/C*%
%TO.C,BAT0*%
X28575000Y6096000D03*
%TO.N,N$39*%
X15367000Y6096000D03*
D15*
%TO.N,GND*%
X21971000Y6096000D03*
%TD*%
D16*
%TO.N,SQW*%
%TO.C,JP2*%
X2032000Y12065000D03*
%TO.N,SCL*%
X2032000Y14605000D03*
%TO.N,SDA*%
X2032000Y17145000D03*
%TO.N,VCC*%
X2032000Y19685000D03*
%TO.N,GND*%
X2032000Y22225000D03*
%TD*%
D17*
%TO.N,SDA*%
%TO.C,R1*%
X11430000Y11684000D03*
%TO.N,VCC*%
X11430000Y1524000D03*
%TD*%
M02*
