%TF.GenerationSoftware,KiCad,Pcbnew,10.99.0-3671-gbe90a7e200*%
%TF.CreationDate,2026-09-09T21:14:04+01:00*%
%TF.ProjectId,kicad_file,6b696361-645f-4666-996c-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.99.0-3671-gbe90a7e200) date 2026-09-09 21:14:04*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMOutline5P*
0 Free polygon, 5 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 5*
0 $1 to $10 corner X, Y*
0 $11 Rotation angle, in degrees counterclockwise*
0 create outline with 5 corners*
4,1,5,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$1,$2,$11*%
%AMOutline6P*
0 Free polygon, 6 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 6*
0 $1 to $12 corner X, Y*
0 $13 Rotation angle, in degrees counterclockwise*
0 create outline with 6 corners*
4,1,6,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$1,$2,$13*%
%AMOutline7P*
0 Free polygon, 7 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 7*
0 $1 to $14 corner X, Y*
0 $15 Rotation angle, in degrees counterclockwise*
0 create outline with 7 corners*
4,1,7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$1,$2,$15*%
%AMOutline8P*
0 Free polygon, 8 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 8*
0 $1 to $16 corner X, Y*
0 $17 Rotation angle, in degrees counterclockwise*
0 create outline with 8 corners*
4,1,8,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$1,$2,$17*%
G04 Aperture macros list end*
%TA.AperFunction,ComponentPad*%
%ADD10Outline8P,-0.889000X0.368236X-0.368236X0.889000X0.368236X0.889000X0.889000X0.368236X0.889000X-0.368236X0.368236X-0.889000X-0.368236X-0.889000X-0.889000X-0.368236X0.000000*%
%TD*%
%TA.AperFunction,WasherPad*%
%ADD11C,1.108000*%
%TD*%
%TA.AperFunction,ViaPad*%
%ADD12C,0.906400*%
%TD*%
G04 APERTURE END LIST*
D10*
%TO.N,N$6*%
%TO.C,U$2*%
X-25400000Y11430000D03*
%TO.N,MISO*%
X-25400000Y8890000D03*
%TO.N,SCK_5V*%
X-25400000Y6350000D03*
%TO.N,MOSI_5V*%
X-25400000Y3810000D03*
%TO.N,TFTCS_5V*%
X-25400000Y1270000D03*
%TO.N,CARDCS_5V*%
X-25400000Y-1270000D03*
%TO.N,TFTDC_5V*%
X-25400000Y-3810000D03*
%TO.N,RESET_5V*%
X-25400000Y-6350000D03*
%TO.N,+5V*%
X-25400000Y-8890000D03*
%TO.N,GND*%
X-25400000Y-11430000D03*
%TD*%
D11*
%TO.N,*%
%TO.C,U$1*%
X-16900000Y-12800000D03*
X-16900000Y7650000D03*
%TD*%
D12*
%TO.N,GND*%
X-7112000Y-4064000D03*
X-3302000Y8382000D03*
X-9652000Y6096000D03*
X-19558000Y-8128000D03*
%TO.N,SCK*%
X-6096000Y2794000D03*
X1524000Y4826000D03*
%TO.N,MOSI*%
X-15494000Y2286000D03*
%TO.N,MISO*%
X6350000Y3048000D03*
%TO.N,+3V3*%
X-8636000Y5334000D03*
X-15494000Y-8382000D03*
%TO.N,CARDCS*%
X19304000Y2032000D03*
X-5334000Y-3302000D03*
%TO.N,N$4*%
X-7620000Y8382000D03*
%TO.N,TFTDC*%
X-5588000Y254000D03*
%TO.N,TFTCS*%
X-7366000Y-1270000D03*
%TO.N,TFTRESET*%
X-508000Y5080000D03*
%TD*%
M02*
