%TF.GenerationSoftware,KiCad,Pcbnew,10.99.0-3758-g2f18d95be7*%
%TF.CreationDate,2026-09-22T03:46:25+01:00*%
%TF.ProjectId,kicad_file,6b696361-645f-4666-996c-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.99.0-3758-g2f18d95be7) date 2026-09-22 03:46:25*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%TA.AperFunction,ComponentPad*%
%ADD10C,1.778000*%
%TD*%
G04 APERTURE END LIST*
D10*
%TO.N,N$1*%
%TO.C,JP1*%
X2540000Y1778000D03*
%TO.N,N$2*%
X5080000Y1778000D03*
%TO.N,N$3*%
X7620000Y1778000D03*
%TO.N,N$4*%
X10160000Y1778000D03*
%TD*%
M02*
