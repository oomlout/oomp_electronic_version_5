%TF.GenerationSoftware,KiCad,Pcbnew,10.99.0-3671-gbe90a7e200*%
%TF.CreationDate,2026-09-10T00:01:54+01:00*%
%TF.ProjectId,kicad_file,6b696361-645f-4666-996c-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.99.0-3671-gbe90a7e200) date 2026-09-10 00:01:54*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%TA.AperFunction,ViaPad*%
%ADD10C,2.540000*%
%TD*%
G04 APERTURE END LIST*
D10*
%TO.N,M*%
X0Y7620000D03*
%TO.N,R*%
X-7620000Y0D03*
%TO.N,L*%
X7620000Y0D03*
%TD*%
M02*
