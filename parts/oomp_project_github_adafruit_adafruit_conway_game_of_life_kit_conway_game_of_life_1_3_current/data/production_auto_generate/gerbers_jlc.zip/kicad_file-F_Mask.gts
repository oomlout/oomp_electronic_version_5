%TF.GenerationSoftware,KiCad,Pcbnew,10.99.0-3671-gbe90a7e200*%
%TF.CreationDate,2026-09-09T23:28:32+01:00*%
%TF.ProjectId,kicad_file,6b696361-645f-4666-996c-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.99.0-3671-gbe90a7e200) date 2026-09-09 23:28:32*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,UNK_HOLE_2*%
X67310000Y3810000D03*
%TD*%
%TO.C,UNK_HOLE_3*%
X3810000Y3810000D03*
%TD*%
%TO.C,UNK_HOLE_1*%
X67310000Y67310000D03*
%TD*%
%TO.C,UNK_HOLE_0*%
X3810000Y67310000D03*
%TD*%
M02*
