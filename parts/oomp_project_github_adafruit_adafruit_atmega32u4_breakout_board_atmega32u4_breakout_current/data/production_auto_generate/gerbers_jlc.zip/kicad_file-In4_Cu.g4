%TF.GenerationSoftware,KiCad,Pcbnew,10.99.0-3671-gbe90a7e200*%
%TF.CreationDate,2026-09-09T23:06:32+01:00*%
%TF.ProjectId,kicad_file,6b696361-645f-4666-996c-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.99.0-3671-gbe90a7e200) date 2026-09-09 23:06:32*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMOutline5P*
0 Free polygon, 5 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 5*
0 $1 to $10 corner X, Y*
0 $11 Rotation angle, in degrees counterclockwise*
0 create outline with 5 corners*
4,1,5,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$1,$2,$11*%
%AMOutline6P*
0 Free polygon, 6 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 6*
0 $1 to $12 corner X, Y*
0 $13 Rotation angle, in degrees counterclockwise*
0 create outline with 6 corners*
4,1,6,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$1,$2,$13*%
%AMOutline7P*
0 Free polygon, 7 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 7*
0 $1 to $14 corner X, Y*
0 $15 Rotation angle, in degrees counterclockwise*
0 create outline with 7 corners*
4,1,7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$1,$2,$15*%
%AMOutline8P*
0 Free polygon, 8 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 8*
0 $1 to $16 corner X, Y*
0 $17 Rotation angle, in degrees counterclockwise*
0 create outline with 8 corners*
4,1,8,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$1,$2,$17*%
G04 Aperture macros list end*
%TA.AperFunction,ComponentPad*%
%ADD10C,1.778000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD11Outline8P,-0.889000X0.368236X-0.368236X0.889000X0.368236X0.889000X0.889000X0.368236X0.889000X-0.368236X0.368236X-0.889000X-0.368236X-0.889000X-0.889000X-0.368236X-90.000000*%
%TD*%
%TA.AperFunction,WasherPad*%
%ADD12C,1.408000*%
%TD*%
%TA.AperFunction,ViaPad*%
%ADD13C,1.008000*%
%TD*%
G04 APERTURE END LIST*
D10*
%TO.N,+5V*%
%TO.C,JP5*%
X-19050000Y10160000D03*
%TO.N,AREF*%
X-16510000Y10160000D03*
%TO.N,PF0*%
X-13970000Y10160000D03*
%TO.N,PF1*%
X-11430000Y10160000D03*
%TO.N,PF4*%
X-8890000Y10160000D03*
%TO.N,PF5*%
X-6350000Y10160000D03*
%TO.N,PF6*%
X-3810000Y10160000D03*
%TO.N,PF7*%
X-1270000Y10160000D03*
%TO.N,PC7*%
X1270000Y10160000D03*
%TO.N,PC6*%
X3810000Y10160000D03*
%TO.N,PB7*%
X6350000Y10160000D03*
%TO.N,PB6*%
X8890000Y10160000D03*
%TO.N,PB5*%
X11430000Y10160000D03*
%TO.N,PB4*%
X13970000Y10160000D03*
%TO.N,GND*%
X16510000Y10160000D03*
%TD*%
D11*
%TO.N,MISO*%
%TO.C,ISP6*%
X20447000Y2540000D03*
%TO.N,VCC*%
X22987000Y2540000D03*
%TO.N,SCK*%
X20447000Y0D03*
%TO.N,MOSI*%
X22987000Y0D03*
%TO.N,RST*%
X20447000Y-2540000D03*
%TO.N,GND*%
X22987000Y-2540000D03*
%TD*%
D12*
%TO.N,*%
%TO.C,CN1*%
X-20590000Y2200000D03*
X-20590000Y-2200000D03*
%TD*%
D10*
%TO.N,GND*%
%TO.C,JP1*%
X16510000Y-10160000D03*
%TO.N,PD7*%
X13970000Y-10160000D03*
%TO.N,PD6*%
X11430000Y-10160000D03*
%TO.N,PD5*%
X8890000Y-10160000D03*
%TO.N,PD4*%
X6350000Y-10160000D03*
%TO.N,PD3*%
X3810000Y-10160000D03*
%TO.N,PD2*%
X1270000Y-10160000D03*
%TO.N,PD1*%
X-1270000Y-10160000D03*
%TO.N,PD0*%
X-3810000Y-10160000D03*
%TO.N,MISO*%
X-6350000Y-10160000D03*
%TO.N,MOSI*%
X-8890000Y-10160000D03*
%TO.N,SCK*%
X-11430000Y-10160000D03*
%TO.N,PB0*%
X-13970000Y-10160000D03*
%TO.N,PE6*%
X-16510000Y-10160000D03*
%TO.N,+3V3*%
X-19050000Y-10160000D03*
%TD*%
D13*
%TO.N,GND*%
X11430000Y5588000D03*
X-5334000Y635000D03*
X0Y8636000D03*
X-10160000Y3810000D03*
X-20828000Y0D03*
X3556000Y-5334000D03*
X13970000Y6096000D03*
X-1397000Y3810000D03*
%TO.N,N$8*%
X0Y-4318000D03*
X13208000Y-6858000D03*
%TO.N,HWB*%
X19685000Y6223000D03*
X3048000Y4699000D03*
%TO.N,PB7*%
X-7112000Y-5588000D03*
%TO.N,PD5*%
X5334000Y-7366000D03*
%TO.N,PE6*%
X-5334000Y2794000D03*
X-20574000Y-4826000D03*
%TO.N,VCC*%
X-4191000Y3302000D03*
X1651000Y-3937000D03*
X18288000Y-5842000D03*
%TO.N,+5V*%
X-16002000Y6985000D03*
%TO.N,RST*%
X-3048000Y-1778000D03*
X12192000Y254000D03*
%TO.N,N$9*%
X0Y-2540000D03*
X13208000Y-3302000D03*
%TD*%
M02*
