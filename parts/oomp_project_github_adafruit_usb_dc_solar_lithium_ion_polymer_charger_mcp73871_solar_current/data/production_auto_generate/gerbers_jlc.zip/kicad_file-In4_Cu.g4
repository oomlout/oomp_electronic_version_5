%TF.GenerationSoftware,KiCad,Pcbnew,10.99.0-3758-g2f18d95be7*%
%TF.CreationDate,2026-09-13T07:18:18+01:00*%
%TF.ProjectId,kicad_file,6b696361-645f-4666-996c-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.99.0-3758-g2f18d95be7) date 2026-09-13 07:18:18*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMOutline5P*
0 Free polygon, 5 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 5*
0 $1 to $10 corner X, Y*
0 $11 Rotation angle, in degrees counterclockwise*
0 create outline with 5 corners*
4,1,5,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$1,$2,$11*%
%AMOutline6P*
0 Free polygon, 6 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 6*
0 $1 to $12 corner X, Y*
0 $13 Rotation angle, in degrees counterclockwise*
0 create outline with 6 corners*
4,1,6,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$1,$2,$13*%
%AMOutline7P*
0 Free polygon, 7 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 7*
0 $1 to $14 corner X, Y*
0 $15 Rotation angle, in degrees counterclockwise*
0 create outline with 7 corners*
4,1,7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$1,$2,$15*%
%AMOutline8P*
0 Free polygon, 8 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 8*
0 $1 to $16 corner X, Y*
0 $17 Rotation angle, in degrees counterclockwise*
0 create outline with 8 corners*
4,1,8,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$1,$2,$17*%
G04 Aperture macros list end*
%TA.AperFunction,ComponentPad*%
%ADD10O,1.508000X3.016000*%
%TD*%
%TA.AperFunction,WasherPad*%
%ADD11C,1.508000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD12C,2.540000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD13Outline8P,-1.270000X0.526051X-0.526051X1.270000X0.526051X1.270000X1.270000X0.526051X1.270000X-0.526051X0.526051X-1.270000X-0.526051X-1.270000X-1.270000X-0.526051X-90.000000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD14O,1.808000X3.616000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD15Outline8P,-0.838200X0.347194X-0.347194X0.838200X0.347194X0.838200X0.838200X0.347194X0.838200X-0.347194X0.347194X-0.838200X-0.347194X-0.838200X-0.838200X-0.347194X-90.000000*%
%TD*%
%TA.AperFunction,ViaPad*%
%ADD16C,1.008000*%
%TD*%
G04 APERTURE END LIST*
D10*
%TO.N,N$7*%
%TO.C,JP3*%
X26035000Y2540000D03*
%TO.N,GND*%
X28575000Y2540000D03*
%TD*%
D11*
%TO.N,*%
%TO.C,CN4*%
X24425000Y32655000D03*
X20025000Y32655000D03*
%TD*%
D10*
%TO.N,N$11*%
%TO.C,JP2*%
X20955000Y2540000D03*
%TO.N,N$4*%
X23495000Y2540000D03*
%TD*%
%TO.N,GND*%
%TO.C,JP1*%
X14478000Y35052000D03*
%TO.N,VCC*%
X11938000Y35052000D03*
%TD*%
D12*
%TO.N,VCC*%
%TO.C,C4*%
X39370000Y20955000D03*
D13*
%TO.N,GND*%
X39370000Y15875000D03*
%TD*%
D14*
%TO.N,GND*%
%TO.C,CN1*%
X33842000Y32254000D03*
X31042000Y29954000D03*
%TO.N,N$10*%
X33842000Y27354000D03*
%TD*%
D15*
%TO.N,GND*%
%TO.C,THERM0*%
X6350000Y25400000D03*
%TO.N,N$8*%
X6350000Y15240000D03*
%TD*%
%TO.N,GND*%
%TO.C,R11*%
X3810000Y25400000D03*
%TO.N,N$16*%
X3810000Y15240000D03*
%TD*%
D10*
%TO.N,BATT*%
%TO.C,JP4*%
X15875000Y2540000D03*
%TO.N,GND*%
X18415000Y2540000D03*
%TD*%
D16*
%TO.N,GND*%
X24130000Y13208000D03*
X25527000Y15621000D03*
X21463000Y19050000D03*
X25781000Y16637000D03*
X22987000Y19050000D03*
X22225000Y19812000D03*
X26670000Y17780000D03*
X22225000Y18288000D03*
X16256000Y14859000D03*
X12700000Y25400000D03*
X11938000Y8128000D03*
%TO.N,N$16*%
X10160000Y14224000D03*
X30480000Y19431000D03*
%TO.N,N$7*%
X19304000Y22225000D03*
%TO.N,N$6*%
X18034000Y19939000D03*
X28829000Y13208000D03*
%TO.N,N$1*%
X7874000Y13462000D03*
X10033000Y36068000D03*
%TO.N,BATT*%
X25146000Y21463000D03*
%TD*%
M02*
