%TF.GenerationSoftware,KiCad,Pcbnew,10.99.0-3758-g2f18d95be7*%
%TF.CreationDate,2026-09-13T07:14:37+01:00*%
%TF.ProjectId,kicad_file,6b696361-645f-4666-996c-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.99.0-3758-g2f18d95be7) date 2026-09-13 07:14:37*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMOutline5P*
0 Free polygon, 5 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 5*
0 $1 to $10 corner X, Y*
0 $11 Rotation angle, in degrees counterclockwise*
0 create outline with 5 corners*
4,1,5,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$1,$2,$11*%
%AMOutline6P*
0 Free polygon, 6 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 6*
0 $1 to $12 corner X, Y*
0 $13 Rotation angle, in degrees counterclockwise*
0 create outline with 6 corners*
4,1,6,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$1,$2,$13*%
%AMOutline7P*
0 Free polygon, 7 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 7*
0 $1 to $14 corner X, Y*
0 $15 Rotation angle, in degrees counterclockwise*
0 create outline with 7 corners*
4,1,7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$1,$2,$15*%
%AMOutline8P*
0 Free polygon, 8 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 8*
0 $1 to $16 corner X, Y*
0 $17 Rotation angle, in degrees counterclockwise*
0 create outline with 8 corners*
4,1,8,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$1,$2,$17*%
G04 Aperture macros list end*
%TA.AperFunction,ComponentPad*%
%ADD10R,1.676400X1.676400*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD11C,1.676400*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD12O,1.508000X3.016000*%
%TD*%
%TA.AperFunction,WasherPad*%
%ADD13C,2.108000*%
%TD*%
%TA.AperFunction,WasherPad*%
%ADD14C,2.308000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD15C,3.200000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD16C,2.540000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD17Outline8P,-1.270000X0.526051X-0.526051X1.270000X0.526051X1.270000X1.270000X0.526051X1.270000X-0.526051X0.526051X-1.270000X-0.526051X-1.270000X-1.270000X-0.526051X-90.000000*%
%TD*%
%TA.AperFunction,WasherPad*%
%ADD18C,1.508000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD19Outline8P,-0.838200X0.347194X-0.347194X0.838200X0.347194X0.838200X0.838200X0.347194X0.838200X-0.347194X0.347194X-0.838200X-0.347194X-0.838200X-0.838200X-0.347194X-90.000000*%
%TD*%
%TA.AperFunction,ViaPad*%
%ADD20C,0.906400*%
%TD*%
%TA.AperFunction,ViaPad*%
%ADD21C,1.016000*%
%TD*%
%TA.AperFunction,ViaPad*%
%ADD22C,1.006400*%
%TD*%
G04 APERTURE END LIST*
D10*
%TO.N,OUT*%
%TO.C,JP3*%
X38100000Y7620000D03*
D11*
%TO.N,GND*%
X38100000Y10160000D03*
%TD*%
D12*
%TO.N,GND*%
%TO.C,JP1*%
X10414000Y30480000D03*
%TO.N,VCC*%
X7874000Y30480000D03*
%TD*%
D13*
%TO.N,*%
%TO.C,CN1*%
X29818000Y30921000D03*
D14*
X29818000Y26421000D03*
%TD*%
D15*
%TO.N,N/C*%
%TO.C,U$4*%
X2540000Y2540000D03*
%TD*%
%TO.N,N/C*%
%TO.C,U$6*%
X2540000Y27940000D03*
%TD*%
%TO.N,N/C*%
%TO.C,U$5*%
X38100000Y2540000D03*
%TD*%
D10*
%TO.N,BATT*%
%TO.C,JP4*%
X2540000Y7620000D03*
D11*
%TO.N,GND*%
X2540000Y10160000D03*
%TD*%
%TO.N,N$11*%
%TO.C,JP5*%
X17780000Y2540000D03*
%TO.N,VCC*%
X20320000Y2540000D03*
%TO.N,N$4*%
X22860000Y2540000D03*
%TD*%
D16*
%TO.N,VCC*%
%TO.C,C4*%
X32766000Y17653000D03*
D17*
%TO.N,GND*%
X32766000Y12573000D03*
%TD*%
D18*
%TO.N,*%
%TO.C,CN4*%
X19345000Y27956000D03*
X14945000Y27956000D03*
%TD*%
D15*
%TO.N,N/C*%
%TO.C,U$7*%
X38100000Y27940000D03*
%TD*%
D19*
%TO.N,GND*%
%TO.C,R11*%
X3302000Y23114000D03*
%TO.N,N$16*%
X3302000Y12954000D03*
%TD*%
%TO.N,GND*%
%TO.C,THERM0*%
X7366000Y23114000D03*
%TO.N,N$8*%
X7366000Y12954000D03*
%TD*%
D20*
%TO.N,GND*%
X20066000Y12192000D03*
D21*
X28448000Y27813000D03*
D20*
X22479000Y15367000D03*
X17399000Y18034000D03*
X18161000Y17272000D03*
X11938000Y13716000D03*
X9906000Y21844000D03*
X18923000Y18034000D03*
X22606000Y16637000D03*
X18161000Y18796000D03*
X12954000Y11176000D03*
X22479000Y14097000D03*
%TO.N,N$6*%
X25273000Y11430000D03*
X13970000Y18923000D03*
%TO.N,N$1*%
X13970000Y13208000D03*
X9652000Y25146000D03*
%TO.N,N$16*%
X22352000Y18542000D03*
D22*
%TO.N,OUT*%
X28194000Y7874000D03*
D20*
X14986000Y21209000D03*
D22*
%TO.N,BATT*%
X7874000Y7620000D03*
D20*
X21082000Y19939000D03*
%TD*%
M02*
