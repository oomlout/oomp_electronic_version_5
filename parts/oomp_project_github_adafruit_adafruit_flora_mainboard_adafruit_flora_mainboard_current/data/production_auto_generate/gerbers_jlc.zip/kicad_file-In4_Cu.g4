%TF.GenerationSoftware,KiCad,Pcbnew,10.99.0-3758-g2f18d95be7*%
%TF.CreationDate,2026-09-12T18:35:10+01:00*%
%TF.ProjectId,kicad_file,6b696361-645f-4666-996c-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.99.0-3758-g2f18d95be7) date 2026-09-12 18:35:10*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMOutline5P*
0 Free polygon, 5 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 5*
0 $1 to $10 corner X, Y*
0 $11 Rotation angle, in degrees counterclockwise*
0 create outline with 5 corners*
4,1,5,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$1,$2,$11*%
%AMOutline6P*
0 Free polygon, 6 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 6*
0 $1 to $12 corner X, Y*
0 $13 Rotation angle, in degrees counterclockwise*
0 create outline with 6 corners*
4,1,6,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$1,$2,$13*%
%AMOutline7P*
0 Free polygon, 7 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 7*
0 $1 to $14 corner X, Y*
0 $15 Rotation angle, in degrees counterclockwise*
0 create outline with 7 corners*
4,1,7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$1,$2,$15*%
%AMOutline8P*
0 Free polygon, 8 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 8*
0 $1 to $16 corner X, Y*
0 $17 Rotation angle, in degrees counterclockwise*
0 create outline with 8 corners*
4,1,8,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$1,$2,$17*%
G04 Aperture macros list end*
%TA.AperFunction,WasherPad*%
%ADD10C,1.508000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD11C,2.540000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD12Outline8P,-0.762000X0.315631X-0.315631X0.762000X0.315631X0.762000X0.762000X0.315631X0.762000X-0.315631X0.315631X-0.762000X-0.315631X-0.762000X-0.762000X-0.315631X90.000000*%
%TD*%
%TA.AperFunction,ViaPad*%
%ADD13C,0.906400*%
%TD*%
G04 APERTURE END LIST*
D10*
%TO.N,*%
%TO.C,ON/OFF0*%
X-11811000Y-1500000D03*
X-11811000Y1500000D03*
%TD*%
%TO.N,*%
%TO.C,CN1*%
X2200000Y16018000D03*
X-2200000Y16018000D03*
%TD*%
D11*
%TO.N,GND*%
%TO.C,GNDTAP2*%
X-9906000Y-17018000D03*
%TD*%
%TO.N,IO10\u002A*%
%TO.C,IO10*%
X14986000Y12700000D03*
%TD*%
%TO.N,IO12\u002A*%
%TO.C,IO12*%
X14986000Y-12700000D03*
%TD*%
%TO.N,+3V3*%
%TO.C,UNK3.3VTAP0*%
X-19685000Y0D03*
%TD*%
%TO.N,D1/TX*%
%TO.C,TX0*%
X-14986000Y-12700000D03*
%TD*%
%TO.N,D0/RX*%
%TO.C,RX0*%
X-18542000Y-6604000D03*
%TD*%
%TO.N,PD1*%
%TO.C,SDA0*%
X-18542000Y6604000D03*
%TD*%
%TO.N,IO9\u002A*%
%TO.C,IO9*%
X18542000Y6604000D03*
%TD*%
%TO.N,GND*%
%TO.C,GND3TAP0*%
X-9906000Y17018000D03*
%TD*%
%TO.N,GND*%
%TO.C,GNDTAP0*%
X19558000Y0D03*
%TD*%
%TO.N,+3V3*%
%TO.C,UNK3V3TAP2*%
X9906000Y17018000D03*
%TD*%
%TO.N,D6\u002A*%
%TO.C,D6*%
X18542000Y-6604000D03*
%TD*%
%TO.N,PD0*%
%TO.C,SCL0*%
X-14986000Y12700000D03*
%TD*%
%TO.N,VCC*%
%TO.C,VCC2*%
X9906000Y-17018000D03*
%TD*%
D12*
%TO.N,MISO*%
%TO.C,JP1*%
X13208000Y-4445000D03*
%TO.N,N/C*%
X10668000Y-4445000D03*
%TO.N,SCK*%
X13208000Y-1905000D03*
%TO.N,MOSI*%
X10668000Y-1905000D03*
%TO.N,RST*%
X13208000Y635000D03*
%TO.N,GND*%
X10668000Y635000D03*
%TD*%
D13*
%TO.N,GND*%
X-14351000Y5334000D03*
X2286000Y-14859000D03*
X-14859000Y-3810000D03*
X0Y-10541000D03*
X-5588000Y6096000D03*
X16002000Y0D03*
X-8636000Y12319000D03*
X3556000Y-2032000D03*
X13843000Y-8001000D03*
X13843000Y4699000D03*
X-5207000Y-14732000D03*
X-2667000Y11176000D03*
X-1905000Y-3048000D03*
X-11938000Y-10287000D03*
X-8128000Y-1270000D03*
X-4191000Y-8763000D03*
X863600Y6858000D03*
%TO.N,+5V*%
X6858000Y6096000D03*
X-889000Y6731000D03*
%TO.N,MOSI*%
X254000Y1397000D03*
%TO.N,MISO*%
X508000Y127000D03*
%TO.N,SCK*%
X-1016000Y2413000D03*
%TO.N,RST*%
X-3429000Y-11049000D03*
X-3556000Y1270000D03*
%TO.N,N$8*%
X-3937000Y-2667000D03*
X-8001000Y-7874000D03*
%TO.N,+3V3*%
X6477000Y4445000D03*
X-6477000Y-14859000D03*
X11684000Y7747000D03*
%TO.N,IO10\u002A*%
X7493000Y-381000D03*
X1016000Y-3429000D03*
%TO.N,IO9\u002A*%
X254000Y-4445000D03*
X7493000Y-1651000D03*
%TO.N,TXLED*%
X-7874000Y-6477000D03*
X-5715000Y3810000D03*
%TO.N,PD0*%
X-7620000Y3556000D03*
%TO.N,VCC*%
X13589000Y7366000D03*
X5461000Y-6985000D03*
%TO.N,N$6*%
X5334000Y-14097000D03*
X-9271000Y3937000D03*
%TO.N,N$13*%
X-11303000Y-3302000D03*
X3810000Y-9652000D03*
%TO.N,D6\u002A*%
X-762000Y-5461000D03*
%TO.N,IO12\u002A*%
X-254000Y-9144000D03*
%TD*%
M02*
