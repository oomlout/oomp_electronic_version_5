%TF.GenerationSoftware,KiCad,Pcbnew,10.99.0-3671-gbe90a7e200*%
%TF.CreationDate,2026-09-10T00:14:42+01:00*%
%TF.ProjectId,kicad_file,6b696361-645f-4666-996c-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.99.0-3671-gbe90a7e200) date 2026-09-10 00:14:42*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMOutline5P*
0 Free polygon, 5 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 5*
0 $1 to $10 corner X, Y*
0 $11 Rotation angle, in degrees counterclockwise*
0 create outline with 5 corners*
4,1,5,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$1,$2,$11*%
%AMOutline6P*
0 Free polygon, 6 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 6*
0 $1 to $12 corner X, Y*
0 $13 Rotation angle, in degrees counterclockwise*
0 create outline with 6 corners*
4,1,6,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$1,$2,$13*%
%AMOutline7P*
0 Free polygon, 7 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 7*
0 $1 to $14 corner X, Y*
0 $15 Rotation angle, in degrees counterclockwise*
0 create outline with 7 corners*
4,1,7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$1,$2,$15*%
%AMOutline8P*
0 Free polygon, 8 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 8*
0 $1 to $16 corner X, Y*
0 $17 Rotation angle, in degrees counterclockwise*
0 create outline with 8 corners*
4,1,8,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$1,$2,$17*%
G04 Aperture macros list end*
%TA.AperFunction,ComponentPad*%
%ADD10C,3.200000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD11O,3.016000X1.508000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD12C,1.676400*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD13Outline8P,-0.838200X0.347194X-0.347194X0.838200X0.347194X0.838200X0.838200X0.347194X0.838200X-0.347194X0.347194X-0.838200X-0.347194X-0.838200X-0.838200X-0.347194X-90.000000*%
%TD*%
%TA.AperFunction,ViaPad*%
%ADD14C,0.906400*%
%TD*%
G04 APERTURE END LIST*
D10*
%TO.N,N/C*%
%TO.C,U$8*%
X22860000Y15240000D03*
%TD*%
D11*
%TO.N,SIGNAL*%
%TO.C,JP1*%
X2667000Y11430000D03*
%TO.N,VIN*%
X2667000Y8890000D03*
%TO.N,GND*%
X2667000Y6350000D03*
%TD*%
D10*
%TO.N,N/C*%
%TO.C,U$1*%
X22860000Y2540000D03*
%TD*%
D12*
%TO.N,SIGNAL*%
%TO.C,JP2*%
X10160000Y1905000D03*
%TO.N,VIN*%
X12700000Y1905000D03*
%TO.N,GND*%
X15240000Y1905000D03*
%TD*%
D13*
%TO.N,N$7*%
%TO.C,LED1*%
X17145000Y10160000D03*
%TO.N,N$4*%
X17145000Y7620000D03*
%TD*%
D14*
%TO.N,GND*%
X5080000Y12954000D03*
X5334000Y3429000D03*
%TO.N,SIGNAL*%
X14732000Y9528900D03*
%TO.N,VIN*%
X11938000Y14224000D03*
%TO.N,N$1*%
X10033000Y15367000D03*
%TO.N,N$3*%
X7874000Y3302000D03*
%TD*%
M02*
