%TF.GenerationSoftware,KiCad,Pcbnew,10.99.0-3671-gbe90a7e200*%
%TF.CreationDate,2026-09-10T00:11:10+01:00*%
%TF.ProjectId,kicad_file,6b696361-645f-4666-996c-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.99.0-3671-gbe90a7e200) date 2026-09-10 00:11:10*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMOutline5P*
0 Free polygon, 5 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 5*
0 $1 to $10 corner X, Y*
0 $11 Rotation angle, in degrees counterclockwise*
0 create outline with 5 corners*
4,1,5,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$1,$2,$11*%
%AMOutline6P*
0 Free polygon, 6 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 6*
0 $1 to $12 corner X, Y*
0 $13 Rotation angle, in degrees counterclockwise*
0 create outline with 6 corners*
4,1,6,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$1,$2,$13*%
%AMOutline7P*
0 Free polygon, 7 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 7*
0 $1 to $14 corner X, Y*
0 $15 Rotation angle, in degrees counterclockwise*
0 create outline with 7 corners*
4,1,7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$1,$2,$15*%
%AMOutline8P*
0 Free polygon, 8 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 8*
0 $1 to $16 corner X, Y*
0 $17 Rotation angle, in degrees counterclockwise*
0 create outline with 8 corners*
4,1,8,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$1,$2,$17*%
G04 Aperture macros list end*
%TA.AperFunction,ComponentPad*%
%ADD10Outline8P,-0.889000X0.368236X-0.368236X0.889000X0.368236X0.889000X0.889000X0.368236X0.889000X-0.368236X0.368236X-0.889000X-0.368236X-0.889000X-0.889000X-0.368236X90.000000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD11O,2.286000X1.143000*%
%TD*%
%TA.AperFunction,ComponentPad*%
%ADD12R,2.413000X2.413000*%
%TD*%
%TA.AperFunction,ViaPad*%
%ADD13C,0.906400*%
%TD*%
G04 APERTURE END LIST*
D10*
%TO.N,GND*%
%TO.C,FTDI0*%
X2514600Y2413000D03*
%TO.N,CTS*%
X5054600Y2413000D03*
%TO.N,VCCOUT*%
X7594600Y2413000D03*
%TO.N,TX*%
X10134600Y2413000D03*
%TO.N,RX*%
X12674600Y2413000D03*
%TO.N,N$2*%
X15214600Y2413000D03*
%TD*%
D11*
%TO.N,GND*%
%TO.C,CN1*%
X11988100Y20561000D03*
X5970100Y20561000D03*
D12*
X12591600Y23236000D03*
X5366600Y23236000D03*
%TD*%
D13*
%TO.N,+3V3*%
X4064000Y16383000D03*
%TO.N,+5V*%
X15341600Y21971000D03*
X15722600Y8128000D03*
%TO.N,DTR*%
X10769600Y9525000D03*
%TO.N,RTS*%
X8356600Y8763000D03*
%TO.N,RTSDTR*%
X9626600Y8763000D03*
%TO.N,VCCIO*%
X8864600Y11049000D03*
%TD*%
M02*
